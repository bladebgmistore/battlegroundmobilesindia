"use client";

import { useSearchParams } from "next/navigation";
import { useState } from "react";
import Link from "next/link";
import { FiArrowLeft, FiCheckCircle, FiCopy, FiDownload, FiShield, FiClock, FiCreditCard } from "react-icons/fi";
import { formatINR, buildUpiUrl, buildQrImageUrl } from "@/lib/store-data";
import { GridBackdrop, SiteFooter, SiteHeader } from "@/components/site-chrome";
import { useStoreSettings } from "@/lib/use-store-settings";
import { readImageAsDataUrl } from "@/lib/image-utils";

export default function PaymentPage() {
  const params = useSearchParams();
  const orderCode = params.get("orderCode") ?? "BG-XXXX";
  const product = params.get("product") ?? "Selected product";
  const amount = Number(params.get("amount") ?? 0);
  const baseAmount = Number(params.get("baseAmount") ?? amount);
  const coupon = params.get("coupon");
  const discount = Number(params.get("discount") ?? 0);
  const uid = params.get("uid") ?? "";

  const { upiId } = useStoreSettings();
  const [copied, setCopied] = useState(false);
  const [showPaidModal, setShowPaidModal] = useState(false);
  const [paymentScreenshot, setPaymentScreenshot] = useState("");
  const [busy, setBusy] = useState(false);

  const upiUrl = buildUpiUrl({ upiId, amount, orderCode, productName: product });
  const qrUrl = buildQrImageUrl(upiUrl);

  const copyUpi = async () => {
    await navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const uploadScreenshot = async (file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await readImageAsDataUrl(file);
      setPaymentScreenshot(dataUrl);
    } catch (e) {
      console.error(e);
    }
  };

  const handlePaid = async () => {
    setBusy(true);
    try {
      // Save screenshot optional info to order or messages if needed, here just show safe popup
      setShowPaidModal(true);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <GridBackdrop />
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 py-10 lg:px-8 lg:py-14">
        <Link href="/" className="inline-flex items-center gap-2 text-[10px] font-black tracking-[.12em] text-[#64748b] hover:text-[#0f172a]">
          <FiArrowLeft /> BACK TO HOME
        </Link>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.05fr_.95fr]">
          {/* Left: QR */}
          <div className="rounded-2xl border border-[#dbe2ec] bg-[#f8fafc] p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#e0eefb] text-[#0f4c81]"><FiCreditCard className="text-xl" /></div>
              <div>
                <p className="text-[10px] font-black tracking-[.15em] text-[#0f4c81]">SECURE UPI PAYMENT</p>
                <h1 className="text-xl font-black text-[#0f172a]">Scan & Pay {formatINR(amount)}</h1>
              </div>
            </div>

            <div className="mt-6 flex flex-col items-center">
              <div className="rounded-2xl bg-white p-4 shadow-[0_20px_60px_rgba(200,242,41,.15)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={qrUrl} alt={`UPI QR for ${formatINR(amount)}`} width={280} height={280} className="h-[280px] w-[280px] object-contain" />
              </div>
              <p className="mt-4 flex items-center gap-2 rounded-full bg-[#c8f229]/10 px-3 py-1.5 text-[10px] font-black tracking-wide text-[#0f4c81]"><FiClock /> QR valid for this order • Amount fixed</p>

              <div className="mt-6 w-full rounded-xl border border-[#e5e8ef] bg-[#f8fafc] p-4">
                <p className="text-[10px] font-black tracking-[.12em] text-[#64748b]">UPI ID</p>
                <div className="mt-2 flex items-center justify-between gap-3">
                  <p className="truncate font-mono text-sm font-black text-[#0f172a]">{upiId}</p>
                  <button onClick={copyUpi} className="inline-flex items-center gap-1.5 rounded-lg border border-[#dbe2ec] bg-[#f1f5fb] px-3 py-2 text-[10px] font-black text-[#0f172a] hover:bg-[#f1f5fb]">
                    <FiCopy /> {copied ? "COPIED" : "COPY"}
                  </button>
                </div>
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="text-[#64748b]">Amount</span>
                  <span className="text-lg font-black text-[#0f4c81]">{formatINR(amount)}</span>
                </div>
                {discount > 0 && (
                  <p className="mt-1 text-right text-[10px] font-bold text-[#64748b]">Coupon {coupon} saved {formatINR(discount)}</p>
                )}
              </div>

              <div className="mt-4 grid w-full grid-cols-2 gap-3">
                <a href={upiUrl} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#c8f229] px-4 py-3.5 text-xs font-black text-[#0c1107] hover:bg-[#d4ff4d] text-center">
                  <FiCreditCard /> OPEN UPI APP
                </a>
                <a href={qrUrl} download={`QR-${orderCode}.png`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#dbe2ec] bg-[#f1f5fb] px-4 py-3.5 text-xs font-black text-[#0f172a] hover:bg-[#f1f5fb]">
                  <FiDownload /> DOWNLOAD QR
                </a>
              </div>

              <p className="mt-4 text-center text-[10px] leading-4 text-[#94a3b8]">UPI apps: Google Pay • PhonePe • Paytm • BHIM • Any UPI app<br />Scanning will open your UPI app with amount pre-filled</p>
            </div>
          </div>

          {/* Right: Order Details */}
          <div className="space-y-5">
            <div className="rounded-2xl border border-[#e5e8ef] bg-[#f8fafc] p-6">
              <p className="text-[10px] font-bold tracking-[.15em] text-[#0f4c81]">ORDER CONFIRMED</p>
              <h2 className="mt-3 text-2xl font-black leading-6 text-[#0f172a]">{product}</h2>
              <div className="mt-5 space-y-2.5 rounded-xl bg-[#f8fafc] p-4 text-sm">
                <div className="flex justify-between"><span className="text-[#64748b]">Order ID</span><span className="font-mono font-black text-[#0f4c81]">{orderCode}</span></div>
                <div className="flex justify-between"><span className="text-[#64748b]">Product</span><span className="font-bold text-[#0f172a] text-right max-w-[60%] truncate">{product}</span></div>
                {uid && <div className="flex justify-between"><span className="text-[#64748b]">Player UID</span><span className="font-mono font-black text-[#0f4c81]">{uid}</span></div>}
                <div className="h-px bg-[#f1f5fb] my-2" />
                <div className="flex justify-between"><span className="text-[#64748b]">Base Price</span><span className="text-[#0f172a]">{formatINR(baseAmount)}</span></div>
                {discount > 0 && <div className="flex justify-between text-[#0f4c81]"><span>Discount ({coupon})</span><span>-{formatINR(discount)}</span></div>}
                <div className="flex justify-between text-base"><span className="font-bold text-[#0f172a]">Payable</span><span className="text-xl font-black text-[#0f4c81]">{formatINR(amount)}</span></div>
              </div>

              <div className="mt-5 rounded-xl border border-[#d9e4f0] bg-[#f3f8fe] p-4">
                <p className="text-xs font-black text-[#0f4c81] flex items-center gap-2"><FiShield /> HOW TO PAY</p>
                <ol className="mt-3 space-y-2 text-xs leading-5 text-[#0f172a]/70 list-decimal list-inside">
                  <li>Open any UPI app (GPay / PhonePe / Paytm)</li>
                  <li>Tap <b className="text-[#0f172a]">Scan & Pay</b> and scan the QR</li>
                  <li>Verify amount <b className="text-[#0f172a]">{formatINR(amount)}</b> and UPI ID <b className="text-[#0f172a]">{upiId}</b></li>
                  <li>Complete payment, then tap <b className="text-[#0f172a]">I Have Paid</b> below</li>
                </ol>
              </div>

              <div className="mt-5 rounded-xl border border-[#dbe2ec] bg-white p-4">
                <p className="text-[10px] font-black tracking-wide text-[#0f4c81]">UPLOAD PAYMENT SCREENSHOT (OPTIONAL)</p>
                <div className="mt-3 flex items-center gap-3">
                  {paymentScreenshot && <img src={paymentScreenshot} alt="Payment screenshot preview" className="h-14 w-14 rounded-lg border border-[#dbe2ec] object-cover" />}
                  <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#dbe2ec] px-4 py-3 text-xs font-bold text-[#0f4c81] hover:bg-[#f1f5fb]">
                    <FiDownload /> CHOOSE IMAGE
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => void uploadScreenshot(e.target.files?.[0])} />
                  </label>
                </div>
              </div>

              <button onClick={handlePaid} disabled={busy} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#c8f229] py-4 text-sm font-black tracking-wide text-[#0c1107] hover:bg-[#d4ff4d] disabled:opacity-60">
                <FiCheckCircle className="text-lg" /> I HAVE PAID - CONFIRM ORDER
              </button>
              <p className="mt-3 text-center text-[10px] text-[#94a3b8]">Your payment will be verified by the admin before delivery. Keep your payment screenshot safe.</p>
            </div>

            <div className="rounded-2xl border border-[#e5e8ef] bg-[#f8fafc] p-5">
              <p className="text-xs font-black tracking-wide text-[#64748b] flex items-center gap-2"><FiShield className="text-[#0f4c81]" /> Buyer Protection</p>
              <ul className="mt-3 space-y-2 text-xs leading-5 text-[#64748b]">
                <li>• Order is saved instantly with ID <b className="text-[#0f172a]/80">{orderCode}</b></li>
                <li>• Admin will verify payment and deliver within minutes</li>
                <li>• Screen-record the payment for safety</li>
              </ul>
            </div>
          </div>
        </div>

        {showPaidModal && (
          <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setShowPaidModal(false)}>
            <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md rounded-2xl border border-[#dbe2ec] bg-white p-6 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#c8f229]/15 text-2xl text-[#0f4c81]"><FiCheckCircle /></div>
              <h3 className="mt-4 text-xl font-black text-[#0f172a]">Payment Noted!</h3>
              <p className="mt-2 text-sm leading-6 text-[#64748b]">Your order <b className="text-[#0f172a]">{orderCode}</b> for <b className="text-[#0f172a]">{formatINR(amount)}</b> has been saved. Admin payment verification will happen shortly before delivery.</p>
              <button onClick={() => setShowPaidModal(false)} className="mt-5 w-full rounded-xl bg-[#0f4c81] py-3 text-xs font-black text-white">CLOSE & FINISH</button>
            </div>
          </div>
        )}
      </main>
      <SiteFooter />
    </>
  );
}
